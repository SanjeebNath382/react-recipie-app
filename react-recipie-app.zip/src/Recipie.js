import React from 'react'

export default function Recipie({title,calories,image,ingredients,cautions}) {
    
    return (
        <div>
        <h1>{title}</h1>
       
        <img src={image} alt='loading'></img>
        <p style={{fontWeight:'bold'}}>calories:{calories}</p>
        <h3 style={{color:"red"}}>caution:{cautions}</h3>
        <p style={{fontWeight:'bold'}}>ingredients:</p>
       
        {ingredients.map(ingredient=>(
            <>
            
            <ul>
            <li>{ingredient.text}</li>
        </ul>
       
        </>
        
        ))}
        
            
        </div>
    )
}
