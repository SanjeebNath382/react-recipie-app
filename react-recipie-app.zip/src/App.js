import React,{useEffect,useState} from 'react';
import Recipie from './Recipie'
import './App.css'
const App= ()=>{
  const [recipies,setrecipies]= useState([])
const [query,setquery]= useState('chicken')
const [search,setsearch] = useState('')
  const APP_ID="d8477522";
  const APP_KEY="1782aae9f5db08327f2e9622e7c31a32";
  const exampleReq= `https://api.edamam.com/search?q=${query}&app_id=${APP_ID}&app_key=${APP_KEY}`



 

 const getRecipies = async()=>{
   const response= await fetch(exampleReq);
   const data= await response.json();
   setrecipies(data.hits);
   
    console.log(data.hits);

 }
 useEffect(()=>{
  getRecipies();
}, [query])
const onChangeHand = (e)=>{
  setsearch(e.target.value)
}
const onSubHand = (e)=>{
  e.preventDefault()
  setquery(search)
  setsearch('')
}

  return(
    <div className='App' onSubmit={onSubHand}>
    <form className='search-form'>
    <input placeholder="search a dish or ingredient" className='search-bar' value={search} onChange={onChangeHand}></input> <button type='submit' className='search-button'>Search</button>
     
       </form>
     {recipies.map(recipie=>(
       {recipie}?
       <Recipie 
        key={recipie.recipe.label}   title={recipie.recipe.label} calories={recipie.recipe.calories} image={recipie.recipe.image} ingredients={recipie.recipe.ingredients} cautions={recipie.recipe.cautions} />
        : <h1>Loading...........</h1>
     ))}
          
    
        
    </div>
   
  )

}
export default App;
